public class Hypotenuse
{
    public static void main( String args [])
    {
        int a = 30;
        int b = 10;
        System.out.println(" The Length of hypotenuse is : " + Math .hypot (a, b));
    }
}
