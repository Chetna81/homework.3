public class Cricle
{
    public static void main( String args [])
    {
        int radius ;
        double area ;
        System.out.println("Enter the radius : 40 ");
        radius =(40);
        area =(40*40)*3.14;
        System.out.println("Area of the circle is : :" +area);
    }
}
