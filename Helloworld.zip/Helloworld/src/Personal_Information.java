public class Personal_Information
{
    public static void main (String [] args)
    {
        System.out.println( "Name : chetna" );
        System.out.println( "Age : 18" );
        System.out.println( "Address : city of london, 80 Hartford Avenue,Postcode : HA3 8NL");
        System.out.println( "Date of Birth : 11 March 1999 ");



    }
}
